const colors = [
    '#f02e08',
    '#0e38a1',
];

const helloMessage =  'Hello, Code-Star!';

// Write your code down here ...

